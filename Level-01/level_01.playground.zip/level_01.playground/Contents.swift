print("Hello, World! 🚀")
print("Hugo's Swift Journey starts now!")
print(2 + 2)
