let name: String = "Hugo"
var age: Int = 29
let goal: String = "Maîtriser Swift en 100 projets !"

print("Bonjour, je m'appelle \(name) et j'ai \(age) ans.")
print("Mon objectif : \(goal)")
print("L'année prochaine, j'aurai \(age + 1) ans.")
